#-------------------------------------------GSE132903 Human AD 195sp-------------------------------------------------------------
setwd('location')
Loading package
library(GEOquery)

## Downloading data set
gset = getGEO('GSE132903', destdir=".",getGPL = F)
## Obtaining expression of matrix and group information
gset=gset[[1]]
pdata=pData(gset)
pdata$ID <- row.names(pdata)
write.csv(pdata,"pdata.csv")
pdata$group <- pdata$"diagnosis:ch1"


#Subsetting data for GSEA
anno <- read.table("GPL10558_annot.txt",sep = "\t",header = T)
dat <- exprSet
dat <- t(dat)
dat <- as.data.frame(dat)
low <- quantile(dat$ZBP1,0.9)
dat$ID <- row.names(dat)
dat1 <- merge(dat,pdata,by = "ID")
dat1$group <- dat1$"diagnosis:ch1"
dat2 <- dat1[which(dat1$group=="AD"),]
dat2$ZBP1 <- dat2$"ILMN_1765994"
dat3 <- dat2[which(dat2$ZBP1 <= quantile(dat2$ZBP1,0.1)),]
dat3$level <- rep("low",10)
dat4 <- dat2[which(dat2$ZBP1 >= quantile(dat2$ZBP1,0.9)),]
dat4$level <- rep("high",10)
dat5 <- rbind(dat3,dat4)
write.csv(dat5,"dat5.csv")
row.names(dat5) <- dat5$ID
which(colnames(dat5) == "ZBP1")
dat6 <- dat5[1:42181]
dat6$level <- dat5$level
dat6$ID <- NULL
dat6$ZBP1 <- NULL
dat7 <- t(dat6)
dat7 <- dat7[1:42179,]
as.data.frame(lapply(dat7, as.numeric))
dat$ID <- row.names(dat)
dat1 <- subset(dat,ID %in% anno$ID)
dat2 <- subset(anno, ID %in% dat$ID)
exprSet=exprs(gset)
boxplot(exprSet,outline=FALSE, notch=T, las=2)

#Loading package
library(limma) 

#Normalize and wirting file
exprSet=normalizeBetweenArrays(exprSet)
boxplot(exprSet,outline=FALSE, notch=T, las=2)
exprSet = as.data.frame(exprSet)
write.csv(exprSet,"GSEA.csv")
